module Configuration
#case insensitive
  INVALID_KEYS=['mandatory','returnValue','ExtraTraceData','reasonPhrase'];
  INVALID_VALUES=['0','Unknown']
  INTERVAL=15
  ACTIVE_TIME=15*60*1000
  ROOT="./"
end
